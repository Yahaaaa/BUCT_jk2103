export default {
	// baseUrl:'http://192.168.2.226:8080',
	baseUrl:'http://192.168.58.242:80/api',
	// baseUrl:'http://127.0.0.1:80/api',
	// baseUrl:'http://192.168.220.1:80/api',
	uploadUrl:''
}