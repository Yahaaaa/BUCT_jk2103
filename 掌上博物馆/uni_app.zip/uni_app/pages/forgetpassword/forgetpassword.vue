<template>
	<view class="max_big">
		<view class="input_flex">
			<view class="input_number">
				新密码:
			</view>
			<u--input placeholder="请输入新密码" border="surround" v-model="newPassword" type="password"></u--input>
		</view>
		<view class="input_flex">
			<view class="input_number">
				手机号:
			</view>
			<u--input placeholder="请输入手机号" border="surround" v-model="phone" type="number"></u--input>
		</view>
		<view class="login_button">
			<u-button type="primary" text="确认修改" @click="toReg"></u-button>
		</view>

	</view>
</template>

<script>
	import { forgetPassword } from "../../api/index.js"
	export default {
		data() {
			return {
				newPassword: '',
				phone: ''
			};
		},
		methods: {
			toLogin() {
				console.log("登录");
			},
			toReg() {
				if(!this.newPassword) return this.$uni.gettitle("密码不能为空!")
				forgetPassword({
					newPassword:this.newPassword,
					phone:this.phone
				}).then(res=>{
					console.log(res,'res');
					if(res.code ==1){
						this.$uni.gettitle(res.msg)
						setTimeout(()=>{
							uni.navigateBack(1)
						},1500)
					}else{
						this.$uni.gettitle(res.msg)
						this.newPassword=''
						this.phone=''
					}
				})
			}
		}
	}
</script>

<style lang="scss">
	.max_big {
		padding: 25rpx;
		margin-top: 400rpx;
	}

	.input_flex {
		display: flex;
		align-items: center;
		width: 700rpx;
		margin-bottom: 40rpx;

		.input_number {
			margin-right: 20rpx;
		}
	}

	.login_button {
		// width: 600rpx;
		display: flex;
		justify-content: center;

		button {
			width: 200rpx !important;
		}

	}
</style>