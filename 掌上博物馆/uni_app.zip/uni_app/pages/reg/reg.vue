<template>
	<view class="max_big">
		<view class="input_flex">
			<view class="input_number">
				账号:
			</view>
			<u--input placeholder="请输入账号" border="surround" v-model="username"></u--input>
		</view>
		<view class="input_flex">
			<view class="input_number">
				密码:
			</view>
			<u--input placeholder="请输入密码" border="surround" v-model="password" type="password"></u--input>
		</view>
		<view class="login_button">
			<u-button type="primary" text="注册" @click="toReg"></u-button>
		</view>

	</view>
</template>

<script>
	import { registerUserinfo } from '../../api/index.js'
	export default {
		data() {
			return {
				username: '',
				password: ''
			};
		},
		methods: {
			toLogin() {
				console.log("登录");
			},
			toReg() {
				registerUserinfo({
					username:this.username,
					password:this.password
				}).then(res=>{
						if(res.code == 1){
							this.$uni.gettitle(res.msg)
							uni.navigateBack()
						}else{
							this.$uni.gettitle(res.msg)
						}
				})
			}
		}
	}
</script>

<style lang="scss">
	.max_big {
		padding: 25rpx;
		margin-top: 400rpx;
	}

	.input_flex {
		display: flex;
		align-items: center;
		width: 700rpx;
		margin-bottom: 40rpx;

		.input_number {
			margin-right: 20rpx;
		}
	}

	.login_button {
		// width: 600rpx;
		display: flex;
		justify-content: center;

		button {
			width: 200rpx !important;
		}

	}
</style>