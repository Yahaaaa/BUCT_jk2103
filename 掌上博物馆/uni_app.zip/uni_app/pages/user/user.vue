<template>
	<view class="bgk_max">
		<view class="bgk_color" @click="goToUserinfo">
			<view class="avater">
				<image :src="userinfo.image" mode=""></image>
			</view>
			<view class="">
				<view class="nickname_name">
					昵称：{{userinfo.nickname?userinfo.nickname:'暂无'}}
				</view>
				<view class="phoen_number">
					电话：{{userinfo.phone?userinfo.phone:'暂无'}}
				</view>
			</view>
		</view>
		<u-cell-group class="bgk_white">
			<u-cell icon="man-delete" title="个人信息" @click="goToUserinfo"></u-cell>
			<u-cell icon="man-delete" title="修改密码" @click="gotoPassword"></u-cell>
			<u-button plain type="error" class="last_button" @click="removeUserinfo">退出登录</u-button>
		</u-cell-group>
	</view>
</template>

<script>
	import {
		getUserinfo
	} from '../../api/index.js'
	export default {
		data() {
			return {
				userinfo: {
					image: 'https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fimg1.doubanio.com%2Fview%2Fgroup_topic%2Fl%2Fpublic%2Fp515017570.jpg&refer=http%3A%2F%2Fimg1.doubanio.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1705561675&t=e3e43c8900b9eb4dbd0b9e2f1f0f5260',
				},
			};
		},
		mounted() {},
		onShow() {
			this.getuserMessage()
		},
		methods: {
			getuserMessage() {
				getUserinfo().then(res => {
					if (res.code == 1) {
						this.userinfo = res.data
					}
				})
			},
			goToUserinfo() {
				uni.navigateTo({
					url: '/pages/userinfo/userinfo'
				})
			},
			gotoPassword(){
				uni.navigateTo({
					url:'/pages/forgetpassword/forgetpassword'
				})
			},
			removeUserinfo() {
				uni.removeStorageSync('token')
				this.$uni.gettitle('退出成功')
				setTimeout(() => {
					uni.redirectTo({
						url: '/pages/login/login'
					})
				}, 1500)
			}
		}
	}
</script>

<style lang="scss">
	page {
		background-color: #f3f3f3;

		.bgk_max {
			background-color: #fff;

			.bgk_color {
				background: #e9feff;
				height: 400rpx;
				weight: 200rpx;
				padding: 0 20rpx;
				display: flex;
				align-items: center;
				// margin-bottom: 20rpx;

				.avater {
					margin-right: 20rpx;
					height: 120rpx;
					width: 120rpx;

					image {
						width: 100%;
						height: 100%;
						border-radius: 50%
					}
				}

				.nickname_name {
					font-size: 34rpx;
					margin-bottom: 10rpx;
				}

				.phoen_number {
					font-size: 28rpx;
				}
			}

			.bgk_white {
				background-color: #fff;

				/deep/ .u-button {
					margin-top: 20px;
				}
			}
		}
	}
</style>