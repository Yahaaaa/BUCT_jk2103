<template>
	<view class="bgk_max">
		<view class="avater_box">
			<view class="">
				头像
			</view>
			<view class="avater">
				<image :src="userinfo.image?userinfo.image:'../../static/logo.png'" mode=""></image>
			</view>
		</view>
		<u-cell  title="账号" :value="userinfo.username"></u-cell>
		<u-cell  title="昵称" :value="userinfo.nickname"></u-cell>
		<u-cell  title="地址" :value="userinfo.address"></u-cell>
		<u-button @click="getEditMessage" type="warning" plain>修改信息</u-button>
		<u-button @click="goBack" type="primary">返回</u-button>
	</view>
</template>

<script>
	import { getUserinfo } from '../../api/index.js'
	export default {
		data() {
			return {
				userinfo: {
					userinfo:'张三',
					nickname:'李四',
					email:'10086@qq.com',
					address:'安徽',
					username:'1'
				},
			};
		},
		mounted() {
			
		},
		onShow() {
			this.getuserMessage()
		},
		methods: {
			getuserMessage() {
				getUserinfo().then(res => {
					if (res.code == 1) {
						this.userinfo = res.data
					}
				})
			},
			getEditMessage(){
				uni.navigateTo({
					url:'/pages/edituserinfo/edituserinfo'
				})
			},
			goBack(){
				uni.navigateBack(1)
			}
		}
	}
</script>

<style lang="scss">
	page{
		background-color: #f3f3f3;
		.bgk_max{
			background-color: #fff;
			
			.avater_box{
				display: flex;
				align-items: center;
				justify-content: space-between;
				padding: 0 30rpx;
				border-bottom: 1rpx solid #f3f3f3;
				.avater{
					width: 80rpx;
					height: 80rpx;
					image{
						border-radius: 50%;
						width: 100%;
						height: 100%;
					}
				}
			}
		}
	}
</style>