<template>
	<view>
		<view class="image">
			<image :src="detail.imageone" mode=""></image>
		</view>
		<view class="name">
			展品名称:{{detail.goodsname || '暂无'}}
		</view>
		<view class="chaodai">
			展品朝代:{{detail.price || '暂无'}}
		</view>
		<view class="des">
			展品描述:{{detail.goodsdes || '暂无'}}
		</view>
		<view class="title">
			评论列表
		</view>
		<view class="" style="background-color: #fff;">
			<view class="" v-for="item in pinglun" :key="item.id" class="pinglunlist" v-if="pinglun.length>0">
				<view class="images">
					<image :src="item.img" mode=""></image>
				</view>
				<view class="">
					<view class="left_message">
						<view class="names">
							{{item.name || '未知用户'}}
						</view>
						<view class="time">
							{{ item.time || '暂无时间'}}
						</view>
					</view>
					<view class="contenst">
						{{item.content || '暂无'}}
					</view>
				</view>
			</view>
			<view class="" v-if="pinglun.length ==0">
				暂无评论
			</view>
		</view>
		<view class="taskcontent">
			<u-input placeholder="请输入评论内容" v-model="contentValue"></u-input>
			<u-button class="button" type="success" @click="fabiaoPinglun">发表</u-button>
		</view>
	</view>
</template>

<script>
	import {
		getGoodsDetail,
		addPinglun,
		pinglunList
	} from '../../api/index.js'
	export default {
		data() {
			return {
				detail: '',
				contentValue: '',
				wenwuid: '',
				pinglun: '',
			};
		},
		onLoad(options) {
			this.getDetail(options.id)
			this.wenwuid = options.id
			this.getPingLunList(options.id)
		},
		methods: {
			getPingLunList(id) {
				pinglunList({
					wuwenid: id
				}).then(res => {
					console.log(res, 'res')
					if (res.code == 1) {
						this.pinglun = res.data
					}
				})
			},
			getDetail(id) {
				getGoodsDetail({
					id: id
				}).then(res => {
					console.log(res);
					if (res.code == 1) {
						this.detail = res.data
					} else {
						this.$uni.gettitle('获取失败!')
					}
				})
			},
			fabiaoPinglun() {
				addPinglun({
					content: this.contentValue,
					wuwenid: this.wenwuid
				}).then(res => {
					console.log(res);
					if (res.code == 1) {
						this.$uni.gettitle(res.msg)
						this.getPingLunList(this.wenwuid)
					}
				})
			}
		}
	}
</script>

<style lang="scss">
	.left_message {
		display: flex;
		// height: 30rpx;
		align-items: center;
		.names{
			font-size: 32rpx;
			color: #000000;
			margin-right: 20rpx;
			color: #999;
		}
		.time{
			font-size: 24rpx;
			color: #666;
		}
	}

	page {
		padding: 25rpx;
		box-sizing: border-box;
		background-color: #f3f3f3;
		padding-bottom: 100rpx;
	}

	.image {
		width: 100%;

		image {
			width: 100%;
			border-radius: 25rpx;
		}
	}

	.name {
		font-size: 34rpx;
		// font-weight: 600;
		margin-top: 20rpx;
		margin-bottom: 20rpx;
	}

	.chaodai {
		font-size: 32rpx;
		color: red;
		margin-bottom: 20rpx;
	}

	.des {
		font-size: 32rpx;
		// color: red;
		// margin-bottom: 20rpx;
	}

	.title {
		font-size: 42rpx;
		font-weight: 600;
		margin-top: 20rpx;
		margin-bottom: 20rpx;
	}

	.taskcontent {
		// width: 100%;
		background-color: #fff;
		position: fixed;
		bottom: 10rpx;
		left: 20rpx;
		right: 20rpx;
		display: flex;

		.u-button {
			width: 20% !important;
		}
	}

	.pinglunlist {
		display: flex;
		margin-bottom: 10rpx;
		border-bottom: 1rpx solid #ddd;
		padding: 10rpx 0;
		box-sizing: border-box;

		.images {
			margin-right: 20rpx;
		}

		image {
			width: 80rpx;
			height: 80rpx;

		}
	}
</style>