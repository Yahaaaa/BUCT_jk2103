<template>
	<view class="u-page">
		<u-search class="search" placeholder="请输入展品名称" v-model="searchWord.goodsname" @search="searchWords"
			@custom="customSearch"></u-search>
		<view class="swiper">
			<u-swiper radius="10" :list="list1" keyName="url" circular></u-swiper>
		</view>
		<u-list @scrolltolower="scrolltolower">
			<view class="flex_goodslist">
				<u-list-item v-for="(item, index) in indexList" :key="index" @scrolltolower="scrolltolower">
					<view class="goods_every" @click="goTodetail(item.id)">
						<view class="class_image">
							<image :src="item.imageone" alt="" />
						</view>
						<view class="class_rightdesc">
							<view class="name">
								展品名称：{{item.goodsname}}
							</view>
							<view class="price">
								朝代：<text>{{item.price}}</text>
							</view>
							<view class="goodsdesc">
								描述：{{item.goodsdes}}
							</view>
						</view>
					</view>
				</u-list-item>
			</view>
		</u-list>
	</view>
</template>

<script>
	import {
		getGoodsList,
		getBannerList,
		getGoodsSearch
	} from '../../api/index.js'
	export default {
		data() {
			return {
				searchWord: {
					goodsname: '',
					pageSize: 10,
					page: 1
				},
				list1: [],
				indexList: [],
				page: 1,
				pageSize: 10,
				total: 0
			}
		},
		onLoad() {
			this.getGoodsListMessage()
			this.getBannerListMessage()
		},
		methods: {
			searchWords() {
				getGoodsSearch(this.searchWord).then(res => {
					if (res.code == 1) {
						this.indexList = res.data
					} else {
						this.$uni.gettitle(res.msg)
						this.searchWord.goodsname =''
					}
				})
			},
			customSearch() {
				getGoodsSearch(this.searchWord).then(res => {
					if (res.code == 1) {
						this.indexList = res.data
					} else {
						this.$uni.gettitle(res.msg)
						this.searchWord.goodsname =''
					}
				})
			},
			getBannerListMessage() {
				this.list1 = []
				getBannerList().then(res => {
					if (res.code == 1) {
						res.data.forEach((item, index) => {
							this.list1.push({
								url: item.bannerImage
							})
						})
					}
				})
			},
			getGoodsListMessage() {
				getGoodsList({
					page: this.page,
					pageSize: this.pageSize
				}).then(res => {
					console.log(res);
					if (res.code == 1) {
						this.indexList = [...this.indexList, ...res.data]
						this.total = res.total
					}
				})
			},
			goTodetail(id) {
				console.log(id);
				uni.navigateTo({
					url: '/pages/detailwenwu/detailwenwu?id=' + id
				})
			},
			scrolltolower() {
				if (this.total > this.indexList.length) {
					this.page++
					this.getGoodsListMessage()
				} else {
					this.$uni.gettitle('没有更多了哦!')
				}
			}
		},
	}
</script>
<style lang="scss">
	page {
		background-color: #f3f3f3;
		padding-bottom: 40rpx;

		.u-search {
			background-color: #e7f0f3 !important;
			padding: 20rpx;
			box-sizing: border-box;

			.u-search__content__input {
				background-color: #dbf3f0;
			}
		}

		.u-swiper__wrapper {
			padding: 0 25rpx;
			box-sizing: content-box;
			border-radius: 80rpx;
			overflow: hidden;
			height: 400rpx !important;

			image {
				height: 100% !important;
				border-radius: 80rpx !important;
			}
		}

		.swiper {
			margin-top: 20rpx;
			border-radius: 20rpx;
			overflow: hidden;
		}

		.flex_goodslist {
			display: flex;
			flex-wrap: wrap;
			justify-content: space-between;
			padding: 0 30rpx;
			box-sizing: border-box;
			border-radius: 20rpx;

			.u-list-item {
				background-color: #fff;
				margin-top: 30rpx;
				width: 48%;
				border-radius: 20rpx;

				.goods_every {
					.class_image {
						height: 288rpx;
						width: 100%;

						image {
							width: 100%;
							height: 100%;
							border-radius: 20rpx 20rpx 0 0;
						}
					}

					.class_rightdesc {
						padding: 0 20rpx;
						box-sizing: border-box;
						padding-bottom: 20rpx;

						.name {
							margin-top: 5rpx;
							font-size: 28rpx;
							display: -webkit-box;
							-webkit-box-orient: vertical;
							-webkit-line-clamp: 2;
							overflow: hidden;
						}

						.price {
							margin-top: 5rpx;
							font-size: 28rpx;

							text {
								color: red;
							}
						}

						.goodsnumber {
							margin-top: 5rpx;
							font-size: 28rpx;
						}

						.goodsdesc {
							// width: 100px;
							display: -webkit-box;
							-webkit-box-orient: vertical;
							-webkit-line-clamp: 3;
							overflow: hidden;
							// color: red;
							// margin-top: 20px;

							margin-top: 5rpx;
							font-size: 28rpx;
							font-weight: 600;
						}
					}

					.add_shopcar {
						display: flex;
						font-size: 28rpx;
						justify-content: space-between;
						padding: 12rpx 30rpx;
						box-sizing: content-box;

						image {
							width: 36rpx;
							height: 36rpx;
						}
					}
				}
			}
		}

	}
</style>