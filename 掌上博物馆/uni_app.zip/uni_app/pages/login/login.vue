<template>
	<view class="max_big">
		<view class="input_flex">
			<view class="input_number">
				账号:
			</view>
			<u--input placeholder="请输入账号" border="surround" v-model="username"></u--input>
		</view>
		<view class="input_flex">
			<view class="input_number">
				密码:
			</view>
			<u--input placeholder="请输入密码" border="surround" v-model="password" type="password"></u--input>
		</view>
		<view class="login_button">
			<u-button type="success" text="登录" @click="toLogin"></u-button>
			<u-button type="primary" text="注册" @click="toReg"></u-button>
		</view>

	</view>
</template>

<script>
	import { getLogin } from '../../api/index.js'
	export default {
		data() {
			return {
				username: 'admin',
				password: '123456'
			};
		},
		methods: {
			toLogin() {
				console.log("登录");
				getLogin({
					username:this.username,
					password:this.password
				}).then(res=>{
					if(res.code == 1){
						this.$uni.gettitle(res.msg)
						uni.setStorageSync('token',res.token)
						setTimeout(()=>{
							uni.switchTab({
								url:'/pages/artlice/artlice'
							})
						},1500)
					}else{
						this.$uni.gettitle(res.msg)
					}
				})
			},
			toReg() {
				uni.navigateTo({
					url: '/pages/reg/reg'
				})
			}
		}
	}
</script>

<style lang="scss">
	.max_big {
		padding: 25rpx;
		margin-top: 480rpx;
	}

	.input_flex {
		display: flex;
		align-items: center;
		width: 700rpx;
		margin-bottom: 40rpx;

		.input_number {
			margin-right: 20rpx;
		}
	}

	.login_button {
		display: flex;
		justify-content: space-around;

		button {
			width: 200rpx !important;
		}

	}
</style>