import request from "@/utils/request.js"

// 接口模板
export function getLogin(data = {}) {
	return request({
		url: '/api/login',
		method: 'post',
		data,
		headers: {
			isToken: false
		},
	})
}

//修改用户信息
export function editUserinfo(data = {}) {
	return request({
		url: '/user/edit',
		method: 'post',
		data,
		headers: {
			isToken: true
		},
	})
}

//获取用户信息
export function getUserinfo(data = {}) {
	return request({
		url: '/user/userinfo',
		method: 'get',
		data,
		headers: {
			isToken: true
		},
	})
}

//获取轮播图
export function getBannerList(data = {}) {
	return request({
		url: '/banner/bannerlist',
		method: 'get',
		data,
		headers: {
			isToken: true
		},
	})
}

//获取文章列表
export function getArticleList(data = {}) {
	return request({
		url: '/article/list',
		method: 'get',
		data,
		headers: {
			isToken: true
		},
	})
}

//获取商品列表
export function getGoodsList(data = {}) {
	return request({
		url: '/goods/list',
		method: 'get',
		data,
		headers: {
			isToken: true
		},
	})
}


//忘记密码
export function forgetPassword(data = {}) {
	return request({
		url: '/user/forgetpassword',
		method: 'post',
		data,
		headers: {
			isToken: true
		},
	})
}

//注册
export function registerUserinfo(data = {}) {
	return request({
		url: '/api/register',
		method: 'post',
		data,
		headers: {
			isToken: true
		},
	})
}
//获取商品详情
export function getGoodsDetail(data = {}) {
	return request({
		url: '/goods/detail',
		method: 'get',
		data,
		headers: {
			isToken: true
		},
	})
}

//搜索接口
export function getGoodsSearch(data = {}) {
	return request({
		url: '/goods/search',
		method: 'get',
		data,
		headers: {
			isToken: true
		},
	})
}

//评论
export function addPinglun(data = {}) {
	return request({
		url: '/pinglun/addpinglun',
		method: 'post',
		data,
		headers: {
			isToken: true
		},
	})
}

//评论列表
export function pinglunList(data = {}) {
	return request({
		url: '/pinglun/pinglunlist',
		method: 'get',
		data,
		headers: {
			isToken: true
		},
	})
}
