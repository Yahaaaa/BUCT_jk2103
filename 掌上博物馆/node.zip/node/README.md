# node_vue_admin

#### 介绍
第一个以node为后端,vue为前端的后台管理项目

