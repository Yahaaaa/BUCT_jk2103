//链接数据库
const db = require("../db/index");

//选择指定要连接的数据库
db.changeUser({ database: "page" }, (err) => {
    if (err) throw err;
});

//导入对密码加密的包
const bcrypt = require("bcryptjs");

//获取个人信息
exports.userinfo = (req, res) => {
    //执行sql语句
    const userinfoSql = `select id,username,email,address,phone,sex,nickname,image,money from user where id=?`;
    db.query(userinfoSql, req.user.id, (err, result) => {
        if (err) {
            return res.send({ code: 0, msg: err.message });
        }
        if (result.length != 1) {
            return res.send({ code: 0, msg: "获取用户信息异常" });
        }
        res.send({
            code: 1,
            msg: "获取用户信息成功",
            data: result[0],
        });
    });
};

//修改个人信息
exports.userinfoedit = (req, res) => {
    console.log(req.user.id, 'req.user.id');
    if (req.user.id == 1) {
        //判断如果id为空直接结束
        //获取需要修改的信息
        const userinfoMessage = {
            id: req.body.id,
            email: req.body.email,
            address: req.body.address,
            phone: req.body.phone,
            image: req.body.image,
            sex: req.body.sex,
            nickname: req.body.nickname,
        };

        //执行sql语句
        const userinfoEditSql = `update user set ? where id=?`;
        db.query(
            userinfoEditSql,
            [userinfoMessage, userinfoMessage.id],
            (err, result) => {
                if (err) {
                    return res.send({ code: 0, msg: err.message });
                }
                if (result.affectedRows !== 1) {
                    return res.send({ code: 0, msg: "修改用户信息失败" });
                }
                res.send({
                    code: 1,
                    msg: "修改用户信息成功",
                });
            }
        );
    } else {
        const userId = req.user.id
        //判断如果id为空直接结束
        if (!userId) {
            res.send({
                code: 0,
                msg: "修改用户信息失败",
            });
        }
        //获取需要修改的信息
        const userinfoMessage = {
            id: userId,
            email: req.body.email,
            address: req.body.address,
            phone: req.body.phone,
            image: req.body.image,
            sex: req.body.sex,
            nickname: req.body.nickname,
        };
        //执行sql语句
        const userinfoEditSql = `update user set ? where id=?`;
        db.query(
            userinfoEditSql,
            [userinfoMessage, userinfoMessage.id],
            (err, result) => {
                if (err) {
                    return res.send({ code: 0, msg: err.message });
                }
                if (result.affectedRows !== 1) {
                    return res.send({ code: 0, msg: "修改用户信息失败" });
                }
                res.send({
                    code: 1,
                    msg: "修改用户信息成功",
                });
            }
        );
    }
};

//删除个人信息
exports.userinfodelete = (req, res) => {
    if (!req.body.id) {
        return res.send({ code: 0, msg: "删除用户信息失败" });
    }
    const deleteId = req.body.id;

    //执行sql语句
    const userinfoDeleteSql = `delete from user where id=?`;
    db.query(userinfoDeleteSql, deleteId, (err, result) => {
        if (err) {
            return res.send({ code: 0, msg: err.message });
        }
        if (result.affectedRows !== 1) {
            return res.send({ code: 0, msg: "删除用户信息失败" });
        }
        res.send({
            code: 1,
            msg: "删除用户信息成功",
        });
    });
};

//新增用户
exports.userinfoadd = (req, res) => {
    if (!req.body.username) return res.send({ code: 0, msg: "用户名不能为空" });
    if (!req.body.password) return res.send({ code: 0, msg: "密码不能为空" });
    if (!req.body.email) return res.send({ code: 0, msg: "邮箱不能为空" });
    if (!req.body.address) return res.send({ code: 0, msg: "地址不能为空" });
    if (!req.body.phone) return res.send({ code: 0, msg: "手机号码不能为空" });
    if (!req.body.sex) return res.send({ code: 0, msg: "性别不能为空" });
    if (!req.body.nickname) return res.send({ code: 0, msg: "昵称不能为空" });

    //获取需要新增的信息
    const userinfoMessage = {
        username: req.body.username,
        password: req.body.password,
        email: req.body.email,
        address: req.body.address,
        phone: req.body.phone,
        image: req.body.image,
        sex: req.body.sex,
        nickname: req.body.nickname,
    };

    //查询数据库是否有这个用户
    const userSql = `select * from user where username=?`
    db.query(userSql, [userinfoMessage.username], (err, result) => {
        if (err) {
            return res.send({ code: 0, msg: err.message })
        }
        if (result.length > 0) {
            return res.send({ code: 0, msg: '用户名已存在!' })
        } else {
            //对密码加密, 第一个参数是要加密的数据, 第二个是加密的次数
            userinfoMessage.password = bcrypt.hashSync(userinfoMessage.password, 10);

            //执行sql语句
            const userinfoAddSql = `insert into user set ?`;
            db.query(userinfoAddSql, userinfoMessage, (err, result) => {
                if (err) {
                    return res.send({ code: 0, msg: err.message });
                }
                if (result.affectedRows !== 1) {
                    return res.send({ code: 0, msg: "新增用户失败" });
                }
                res.send({
                    code: 1,
                    msg: "新增用户成功",
                });
            });
        }
    })
};

//重置密码
exports.resetPassword = (req, res) => {
    const { newPassword, oldPassword } = req.body;
    if (!newPassword) return res.send({ code: 0, msg: "新密码不能为空" });
    if (!oldPassword) return res.send({ code: 0, msg: "旧密码不能为空" });
    if (oldPassword == newPassword)
        return res.send({ code: 0, msg: "旧密码和新密码不能相同" });

    const userId = req.user.id; //解析的密码
    //执行数据库语句
    const userSql = `select * from user where id=?`;
    db.query(userSql, userId, (err, result) => {
        if (err) return res.send({ code: 0, msg: err.message });
        if (result.length != 1) return res.send({ code: 0, msg: "用户不存在" });
        const user = result[0];

        //判断密码是否正确
        const compareSyncResult = bcrypt.compareSync(oldPassword, user.password);
        if (!compareSyncResult) return res.send({ code: 0, msg: "旧密码错误" });

        //修改密码sql语句
        const updateSql = `update user set password=? where id=?`;

        //对新密码进行加密
        const newP = bcrypt.hashSync(newPassword, 10);

        //将数据存放在一个数组之中
        const updateMessage = [newP, userId];
        db.query(updateSql, updateMessage, (err, result) => {
            if (err) return res.send({ code: 0, msg: err.message });
            if (result.affectedRows != 1)
                return res.send({ code: 0, msg: "修改密码失败" });
            res.send({ code: 1, msg: "修改密码成功" });
        });
    });
};

//获取所用用户
exports.getAllUsers = (req, res) => {
    const AllUserSql = `select * from user where status = 0`; //查询所有用户sql语句
    db.query(AllUserSql, (err, result) => {
        if (err) return res.send({ code: 0, msg: err.message });
        res.send({ code: 1, data: result });
    });
}

//获取单个用户的信息
exports.getUserInfo = (req, res) => {
    const userId = req.query.id;
    if (!userId) return res.send({ code: 0, msg: 'id不能为空!' })
    const getUserInfoSql = `select * from user where id=?`;
    db.query(getUserInfoSql, userId, (err, result) => {
        if (err) return res.send({ code: 0, msg: err.message })
        if (result.length !== 1) return res.send({ code: 0, msg: "查询用户失败!!" })
        res.send({ code: 1, data: result[0] })
    })
}
//查询某个人的信息
exports.SearchUserInfo = (req, res) => {
    const searchWord = req.query
    var search = `username  like '%${searchWord.username}%' `
    const searchSql = `select * from user where  ${search} and status = 0`
    db.query(searchSql, searchWord.author, (err, result) => {
        if (err) return res.send({ code: 0, msg: err.message })
        console.log(result);
        if (result.length == 0) return res.send({ code: 0, msg: "没有搜索到相关用户" })
        res.send({ code: 1, data: result, total: result.length })
    })
}


//忘记密码
exports.changePassword = (req, res) => {
    //拿到当前这个登录的这个人的id
    const userId = req.user.id;
    let sqlSelect = `select * from user where id=?`;
    db.query(sqlSelect, userId, (err, result) => {
        if (err) return res.send({ code: 0, msg: err.message });
        if (result.length != 1) return res.send({ code: 0, msg: "用户不存在" });

        //获取前端传过来的手机号和这个人的id查出来的手机号是否一致
        const { phone, newPassword } = req.body;
        if (!phone) return res.send({ code: 0, msg: "手机号不能为空" });
        if (!newPassword) return res.send({ code: 0, msg: "新密码不能为空" });

        //判断手机号是否正确
        if (result[0].phone != phone) return res.send({ code: 0, msg: "手机号不正确" });

        //对密码加密
        const newP = bcrypt.hashSync(newPassword, 10);
        //修改密码sql语句
        const updateSql = `update user set password=? where id=?`;
        const updateMessage = [newP, userId];
        db.query(updateSql, updateMessage, (err, result) => {
            if (err) return res.send({ code: 0, msg: err.message });
            if (result.affectedRows != 1) return res.send({ code: 0, msg: "修改密码失败" });
            res.send({ code: 1, msg: "修改密码成功" });
        })

    })
}