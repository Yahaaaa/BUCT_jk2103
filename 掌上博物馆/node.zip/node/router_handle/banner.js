const db = require('../db/index')

//选择指定要连接的数据库
db.changeUser({ database: "page" }, (err) => {
    if (err) throw err;
});

//获取轮播图列表
exports.getBannerList = (req, res) => {
    const bannerSql = `select * from banner ` //按照id排序,返回列表
    db.query(bannerSql, (err, result) => {
        if (err) return res.send({ code: 0, msg: err.message })

        res.send({ code: 1, data: result, msg: '获取成功!', total: result.length })
    })
}

//新增轮播图接口
exports.addBannerList = (req, res) => {
    if (!req.body.bannerName) return res.send({ code: 0, msg: '轮播图名称不能为空' })
    if (!req.body.bannerImage) return res.send({ code: 0, msg: '请上传轮播图' })
    const bannerMessage = {
        bannerName: req.body.bannerName,
        bannerImage: req.body.bannerImage,
        createtime: new Date().getTime(),
    }

    //执行数据库语句,看看是否有这个书名
    const bannerSqlSearch = `select * from banner where bannerName = ?`
    db.query(bannerSqlSearch, [req.body.bannerName], (err, result) => {
        if (err) return res.send({ code: 0, msg: err.message })
        if (result.length > 0) {
            return res.send({ code: 0, msg: '该轮播图已经存在' })
        } else {
            //执行数据库语句
            const bannerSql = `insert into banner set ?`
            db.query(bannerSql, bannerMessage, (err, result) => {
                if (err) return res.send({ code: 0, msg: err.message })
                res.send({ code: 1, msg: '添加成功' })
            })
        }
    })
}

//修改轮播图接口
exports.editBannerList = (req, res) => {
    //判断如果id为空直接结束
    if (!req.body.id) return res.send({ code: 0, msg: '修改失败' })
    if (!req.body.bannerName) return res.send({ code: 0, msg: '轮播图名称不能为空' })
    if (!req.body.bannerImage) return res.send({ code: 0, msg: '请上传轮播图' })
    //获取需要修改的数据
    const updateMessage = {
        id: req.body.id,
        bannerName: req.body.bannerName,
        bannerImage: req.body.bannerImage,
        createtime: new Date().getTime(),
    }
    //执行sql语句
    const bannerSql = `update banner set ? where id = ?`
    db.query(bannerSql, [updateMessage, req.body.id], (err, result) => {
        if (err) return res.send({ code: 0, msg: err.message })
        if (result.affectedRows !== 1) return res.send({ code: 0, msg: "修改轮播图失败!" })
        res.send({ code: 1, msg: '修改轮播图成功!' })
    })
}

//删除轮播图
exports.deleteBannerList = (req, res) => {
    if (!req.body.id) return res.send({ code: 0, msg: 'id不能为空!' })
    const bannerSql = `delete from banner where id = ?`
    db.query(bannerSql, [req.body.id], (err, result) => {
        if (err) return res.send({ code: 0, msg: err.message })
        if (result.affectedRows !== 1) return res.send({ code: 0, msg: "删除轮播图失败!" });
        res.send({ code: 1, msg: '删除成功!' })
    })
}

//获取轮播图详情
exports.bannerDetail = (req, res) => {
    if (!req.query.id) return res.send({ code: 0, msg: "查询轮播图详情失败!" })
    const bannerId = req.query.id
    const sql = `select * from banner where id = ?`
    db.query(sql, [bannerId], (err, result) => {
        if (err) return res.send({ code: 0, msg: err.message })
        if (result.length !== 1) return res.send({ code: 0, msg: "查询轮播图详情失败!" })
        res.send({ code: 1, data: result[0] })
    })
}