const db = require('../db/index')

//选择指定要连接的数据库
db.changeUser({ database: "page" }, (err) => {
    if (err) throw err;
})

// 获取评论列表
 exports.getPinglunList = (req, res) => {
     //前端传过来文物的id,查相关的评论
     const wuwenid = req.query.wuwenid
     //查询评论表
     db.query(`SELECT * FROM pinglun WHERE wuwenid = ${wuwenid}`, (err, results) => {
         if (err) return res.send(err)
         res.send({
             code: 1,
             msg: '获取评论列表成功',
             data: results
         })
     })
 }

 //添加评论
 exports.addPinglun = (req, res) => {
     //获取评论内容
     const content = req.body.content
     //获取文物的id
     const wuwenid = req.body.wuwenid
     //获取当前评论人的id
     const userid = req.user.id
    //  用当前这个人的id去查数据库
     db.query(`SELECT * FROM user WHERE id = ${userid}`, (err, results) => {
         if (err) return res.cc(err)
         //获取评论人的名字
         const username = results[0].username
         //获取评论人的头像
         const image = results[0].image
         //获取当前的时间,格式为2024-05-06 09:00:00
         const time = new Date().toLocaleString()
         //插入评论
         db.query(`INSERT INTO pinglun(content,wuwenid,userid,name,img,time) VALUES('${content}',${wuwenid},${userid},'${username}','${image}','${time}')`, (err, results) => {
             if(err) return res.send(err)
                
             res.send({
                     code: 1,
                     msg: '评论成功',
                    //  data: results
                })
         })
    })

 }

 //删除评
 exports.deletePinglun = (req, res) => {
      
     //获取评论的id
     const id = req.query.id
     //删除评论
     db.query(`DELETE FROM pinglun WHERE id = ${id}`, (err, results) => {
         if(err) return res.send(err)
         res.send({
             code: 1,
             msg: '删除评论成功',
            //  data: results
         })
     })
 }


 //查询所有的评论
 exports.getAllPinglun = (req, res) => {
     db.query(`SELECT * FROM pinglun`, (err, results) => {
         if (err) return res.send(err)
         res.send({
             code: 1,
             msg: '获取评论列表成功',
             data: results
             
         })
         
     })
 }