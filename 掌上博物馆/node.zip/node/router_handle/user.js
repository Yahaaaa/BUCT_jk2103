//链接数据库
const db = require('../db/index')

//导入对密码加密的包
const bcrypt = require('bcryptjs')

//生成token
const jwt = require('jsonwebtoken')
const config = require('../config')

//注册
exports.regUser = (req, res) => {
    const userinfo = req.body //获取用户端提交的表单数据
    console.log(userinfo, 'userinfouserinfo');
    if (!userinfo.username || !userinfo.password) {
        return res.send({
            code: 0,
            msg: '用户名或密码不能为空!'
        });
    }

    //选择指定要连接的数据库
    db.changeUser({ database: 'page' }, (err) => {
        if (err) throw err;
    });

    //查询数据库是否有这个用户
    const userSql = `select * from user where username=?`
    db.query(userSql, [userinfo.username], (err, result) => {
        if (err) {
            return res.send({ code: 0, msg: err.message })
        }
        if (result.length > 0) {
            return res.send({ code: 0, msg: '用户名已存在!' })
        } else {
            //对密码加密, 第一个参数是要加密的数据, 第二个是加密的次数
            userinfo.password = bcrypt.hashSync(userinfo.password, 10)

            //存储用户注册是数据
            const insertUser = `insert into user set ?`
            db.query(insertUser, { username: userinfo.username, password: userinfo.password }, (err, result) => {
                if (err) {
                    return res.send({ code: 0, msg: err.message })
                }
                if (result.affectedRows !== 1) {
                    return res.send({ code: 0, msg: '注册用户失败,请稍后再试!' })
                }
                res.send({ code: 1, msg: '注册成功!' })
            })
        }
    })


}


//登录
exports.loginUser = (req, res) => {
    const userinfo = req.body;
    console.log(userinfo, 'userinfouserinfo');
    //如果用户名或者密码为空直接提示必填信息
    if (!userinfo.username || !userinfo.password) {
        return res.send({
            code: 0,
            msg: '用户名或密码不正确'
        });
    }
    //选择指定要连接的数据库
    db.changeUser({ database: 'page' }, (err) => {
        if (err) throw err;
    });

    const selectSql = 'select * from user where username=?'
    db.query(selectSql, [userinfo.username], (err, result) => {
        if (err) throw err
        if (result.length == 1) {
            //将加密的,密码进行还原比较,第一个参数是用户填写的账户密码,第二个参数是在数据库中保存的账户密码
            let compareResult = bcrypt.compareSync(userinfo.password, result[0].password)
            //compareResult的返回值是true或者是false.
            if (!compareResult) return res.send({
                code:0,
                msg:'用户名或密码不正确'
            })

            //清楚用户的敏感信息,方便生成token
            const user = { ...result[0], password: '', email: '' }
            //生成token
            const tokenStr = jwt.sign(user, config.jwtSecretKey, { expiresIn: config.expiresIn })
            //响应数据
            res.send({
                code: 1,
                msg: '登陆成功!',
                token: 'Bearer ' + tokenStr
            })
        } else {
            res.send({ code: 0, msg: '用户名或密码不正确' })
        }
    })
}


