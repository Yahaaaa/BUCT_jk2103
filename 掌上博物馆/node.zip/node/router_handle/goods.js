const db = require('../db/index')

//选择指定要连接的数据库
db.changeUser({ database: "page" }, (err) => {
    if (err) throw err;
});

// 商品列表
exports.goodsList = (req, res) => {
    const { page, pageSize } = req.query; // 获取前端传递的page和pageSize参数  
    //查看总有多少条数据
    const articleSqlTotal = `select * from goods ` //按照id排序,返回列表
    //总条数
    var total = 0
    db.query(articleSqlTotal, (err, result) => {
        if (err) return res.send({ code: 0, msg: err.message })
        total = result.length
    })
    // 构建分页查询语句  
    const articleSql = `SELECT * FROM goods ORDER BY id LIMIT ${pageSize}  OFFSET ${(page - 1) * pageSize}`;

    db.query(articleSql, (err, result) => {
        if (err) return res.send({ code: 0, msg: err.message });

        res.send({ code: 1, data: result, msg: '获取成功!', total: total });
    });
};

// 增加商品
exports.goodsAdd = (req, res) => {
    if (!req.body.goodsname || !req.body.goodsdes || !req.body.price  || !req.body.imageone )
        return res.send({
            code: 0, msg: '参数错误!'
        })

    const goodsAddMessage = {
        goodsname: req.body.goodsname,
        goodsdes: req.body.goodsdes,
        price: req.body.price,
        goodsnumber: req.body.goodsnumber,
        imageone: req.body.imageone,
    }
    const goodsSqlSearch = `select * from goods where goodsname = ?`
    db.query(goodsSqlSearch, goodsAddMessage.goodsname, (err, result) => {
        if (err) return res.send({ code: 0, msg: err.message });
        if (result.length > 0) return res.send({ code: 0, msg: '商品已存在!' });
        const goodsAddSql = `insert into goods set ?`
        db.query(goodsAddSql, goodsAddMessage, (err, result) => {
            if (err) return res.send({ code: 0, msg: err.message });
            if (result.affectedRows > 0) return res.send({ code: 1, msg: '添加成功!' });
        })
    })
}


// 修改商品
exports.goodsUpdate = (req, res) => {
    if(!req.body.id) return res.send({code:0,msg:'参数错误!'})
    const goodsUpdateMessage = {
        id: req.body.id,
        goodsname: req.body.goodsname,
        goodsdes: req.body.goodsdes,
        price: req.body.price,
        goodsnumber: req.body.goodsnumber,
        imageone: req.body.imageone,
        // imagetwo: req.body.imagetwo
    }
    const goodsUpdateSql = `update goods set ? where id = ?`
    db.query(goodsUpdateSql,[goodsUpdateMessage,goodsUpdateMessage.id],(err,result)=>{
        if(err) return res.send({code:0,msg:err.message})
        if(result.affectedRows > 0) return res.send({code:1,msg:'修改成功!'})
    })
}

//删除商品
exports.goodsDelete = (req, res) => {
    if(!req.body.id) return res.send({code:0,msg:'参数错误!'})
    const goodsDeleteSql = `delete from goods where id = ?`
    db.query(goodsDeleteSql,req.body.id,(err,result)=>{
        if(err) return res.send({code:0,msg:err.message})
        if(result.affectedRows > 0) return res.send({code:1,msg:'删除成功!'})
    })
}

//商品详情
exports.goodsDetail = (req, res) => {
    if(!req.query.id) return res.send({code:0,msg:'参数错误!'})
    const goodsId = req.query.id
    const goodsDetailSql = `select * from goods where id = ?`
    db.query(goodsDetailSql,[goodsId],(err,result)=>{
        if(err) return res.send({code:0,msg:err.message})
        if(result.length > 0) return res.send({code:1,data:result[0]})
    })
}

//搜索接口
exports.goodsSearch = (req, res) => {
    //定义搜索关键字
    const searchWord = req.query
    const { page, pageSize } = req.query;
    var search = `goodsname  like '%${searchWord.goodsname}%'`
    const searchSql = `select * from goods where  ${search} LIMIT ${pageSize}  OFFSET ${(page - 1) * pageSize}`
    db.query(searchSql, searchWord.goodsname, (err, result) => {
        if (err) return res.send({ code: 0, msg: err.message })
        if (result.length == 0) return res.send({ code: 0, msg: "没搜到相关商品信息" })
        res.send({ code: 1, data: result ,total:result.length})
    })
}
