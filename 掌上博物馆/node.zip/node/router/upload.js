const express = require("express");
const router = express.Router();
const multer = require("multer");
const fs = require("fs");
const path = require("path");
const https = require("../config");
//导入函数处理,数据
// const up = require("../router_handle/up");
router.post(
  "/up", multer({
    //接收图片所存在当前目录下的public/images文件夹下
    dest: "public/images/",
  }).array("file", 1),
  function (req, res, next) {
    let files = req.files;
    let file = files[0];
    let fileInfo = {};
    let path =
      "public/images/" + Date.now().toString() + "_" + file.originalname;
    fs.renameSync("./public/images/" + file.filename, path);
    //获取文件的基本信息
    fileInfo.type = file.mimetype;
    fileInfo.name = file.originalname;
    fileInfo.size = file.size;
    //所存放的路径，这个很重要
    fileInfo.path = 'http://192.168.58.242:80' + '/' + path;
    // fileInfo.path = https.http_location + '/' + path;
    res.send({
      code: 1,
      msg: "OK",
      data: fileInfo,
    });
  }
);
module.exports = router;
