const express = require('express');
const router = express.Router();

//导入用户处理函数的路由模块
const userinfoDetail = require('../router_handle/userinfo');

// 获取个人信息
router.get('/userinfo', userinfoDetail.userinfo);

// 修改个人信息
router.post('/edit', userinfoDetail.userinfoedit);

// 删除用户信息
router.post('/delete', userinfoDetail.userinfodelete);

// 新增用户信息
router.post('/add', userinfoDetail.userinfoadd);

//重置密码
router.post('/resetpassword', userinfoDetail.resetPassword);

//获取所有用户
router.get('/alluser', userinfoDetail.getAllUsers);

//查看单个用户的信息
router.get('/everyuserinfo', userinfoDetail.getUserInfo);

// 查询某个人的信息
router.get('/searchuserinfo', userinfoDetail.SearchUserInfo);

//忘记密码
router.post('/forgetpassword', userinfoDetail.changePassword);

module.exports = router