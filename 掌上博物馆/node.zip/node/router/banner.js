const express = require('express');
const router = express.Router();
const bannerList  = require('../router_handle/banner')

router.get('/bannerlist',bannerList.getBannerList)
router.post('/banneradd',bannerList.addBannerList)
router.post('/banneredit',bannerList.editBannerList)
router.post('/bannerdelete',bannerList.deleteBannerList)
router.get('/bannerdetail',bannerList.bannerDetail)



module.exports = router;