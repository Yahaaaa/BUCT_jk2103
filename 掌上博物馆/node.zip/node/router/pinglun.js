const express = require('express');
const router = express.Router();
const bannerList = require('../router_handle/pinglun')

router.get('/pinglunlist', bannerList.getPinglunList)

// 添加评论
router.post('/addpinglun', bannerList.addPinglun)

//删除评论
router.get('/deletepinglun', bannerList.deletePinglun)

//获取所有的评论
router.get('/getallpinglun', bannerList.getAllPinglun)

module.exports = router;