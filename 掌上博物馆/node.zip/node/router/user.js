const express = require('express');
const router = express.Router();

//导入用户处理函数的路由模块
const userMessage = require('../router_handle/user');

// 注册
router.post('/register', userMessage.regUser);

// 登录
router.post('/login', userMessage.loginUser);



module.exports = router