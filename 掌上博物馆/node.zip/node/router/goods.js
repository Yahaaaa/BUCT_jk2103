const express = require('express');
const router = express.Router();
const goodsMessage = require('../router_handle/goods')

//商品列表
router.get('/list',goodsMessage.goodsList)

//增加商品
router.post('/add',goodsMessage.goodsAdd)

//修改商品
router.post('/update',goodsMessage.goodsUpdate)

//删除商品
router.post('/delete',goodsMessage.goodsDelete)

//商品详情
router.get('/detail',goodsMessage.goodsDetail)

//搜索
router.get('/search',goodsMessage.goodsSearch)
module.exports = router;