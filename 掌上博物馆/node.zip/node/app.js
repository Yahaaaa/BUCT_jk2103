//搭建框架
const express = require('express');
const app = express()


const path = require("path");
// 解决文件上传太大的中间件
var bodyParser = require("body-parser");
app.use(bodyParser.json({ limit: "50mb" }));
app.use(bodyParser.urlencoded({ limit: "50mb", extended: true }));

//解决跨域
const cors = require('cors')
app.use(cors())

//解析表单内容
app.use(express.urlencoded({ extended: false }))


//一定要在路由之前配置解析token中间件
const expressJWT = require('express-jwt')
const config = require('./config')
app.use(expressJWT({ secret: config.jwtSecretKey }).unless({
    path: [/^\/api\/api/, /^\/public\/images/]
}))



//导入使用路由,模块
const userRouter = require('./router/user.js')
const userinfoRouter = require('./router/userinfo.js')
const upload = require('./router/upload.js')
const bannerRouter = require('./router/banner.js')
const goodsRouter = require('./router/goods.js')
const pinglunRouter = require('./router/pinglun.js')


app.use("/public/images/", express.static(path.join(__dirname, "/public/images/")));
app.use("/api/api", userRouter)//登录注册
app.use("/api/user", userinfoRouter)//个人信息
app.use("/api/upload", upload)//上传接口
app.use("/api/banner", bannerRouter)//轮播图
app.use("/api/goods", goodsRouter)//商品
app.use("/api/pinglun", pinglunRouter)//评论








//定义错误中间件 --判断是不是401,如果是401,直接返回登录页
app.use((err, req, res, next) => {
    console.log(err);
    if (err.status === 401){
        res.send({
            code: 401,
            msg: '无效的token'
        })
    }else{
        next()
    }
})

app.listen(80, () => {console.log('Servidor iniciado')})