module.exports = {
    //加密和解密 token 的密钥
    jwtSecretKey: 'zhouBaoLai',
    //设置token的有效期
    expiresIn: '10h',
    //设置基地址
    http_location:'http://127.0.0.1:80',
    //设置数据库名称
    db_host:'page',
}