//导入数据库
const mysql =require('mysql')
// 链接数据库
const db = mysql.createConnection({
    host:'127.0.0.1',
    user:'root',
    password:'20030423',
    datebase:'page'
})
//暴露数据库
module.exports = db